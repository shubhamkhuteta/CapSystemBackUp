export class Admin {

    adminId: number;
    adminName: string;
    adminPassword: string;


    constructor(adminId: number,
        adminName: string,
        adminPassword: string,
    ) {
        this.adminId = adminId;
        this.adminName = adminName;
        this.adminPassword = adminPassword;


    }
}