export class Customer {

    customerId: number;
    customerName: string;
    customerPassword: string;
    customerContactNo: string;
    customerAddress: string;
    customerStatus: string;
    customerQuestion: number;
    customerAnswer: string;

    constructor(customerId: number,
        customerName: string,
        customerPassword: string,
        customerContactNo: string,
        customerAddress: string,
        customerStatus: string,
        customerQuestion: number,
        customerAnswer: string)
    {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerPassword = customerPassword;
        this.customerContactNo = customerContactNo;
        this.customerAddress = customerAddress;
        this.customerStatus = customerStatus;
        this.customerQuestion = customerQuestion;
        this.customerAnswer = customerAnswer;

    }
}