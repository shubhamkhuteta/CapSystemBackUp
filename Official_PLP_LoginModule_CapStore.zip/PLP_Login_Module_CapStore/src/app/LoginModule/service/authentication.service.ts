import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private myRoute: Router) { }
  adminId:string;
  customerId:string;
  merchantId:string;

  sendToken(token: string) {
    localStorage.setItem("LoggedInUser", token)
  }

  getToken() {
    if(!localStorage.getItem("AdminUserId")===null){
      return localStorage.getItem("AdminUserId");
    }else if(!localStorage.getItem("CustomerUserId")===null){
      return localStorage.getItem("CustomerUserId");
    }else if(!localStorage.getItem("MerchantUserId")===null){
      return localStorage.getItem("MerchantUserId");
    }else{
      return null;
    }
  }

  isLoggedIn() {
    if(!localStorage.getItem("AdminUserId")===null){
      this.myRoute.navigate(['adindashboard']);
      return true;
    }else if(!localStorage.getItem("CustomerUserId")===null){
      this.myRoute.navigate(['customermerchant']);
      return true;
    }else if(!localStorage.getItem("MerchantUserId")===null){
      this.myRoute.navigate(['merchantdashboard']);
      return true;
    }else{
      return false;
    }
  }
  
  logout() {
    localStorage.removeItem("LoggedInUser");
    this.myRoute.navigate(['/login']);
  }
}