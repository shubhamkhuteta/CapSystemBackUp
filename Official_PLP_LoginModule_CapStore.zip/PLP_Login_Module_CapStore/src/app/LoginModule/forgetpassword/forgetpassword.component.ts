import { Component, OnInit } from '@angular/core';
import { LoginService } from '../service/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {
  login:LoginService;
  router:Router;
  constructor(login:LoginService,router:Router) { 
    this.login=login;
    this.router=router;
  }

  ngOnInit() {
  }


  forgetPassword(data:any){

    let result:boolean;
    this.login.forgetPassword(data)

    //result=
    // if(this.login.forgetPassword(data)){
    //   alert("Account recovered successfully")
    //   this.router.navigate(['login'])
    // }
    // else{
    //   alert("Please enter valid details");
    // }

  }

}
