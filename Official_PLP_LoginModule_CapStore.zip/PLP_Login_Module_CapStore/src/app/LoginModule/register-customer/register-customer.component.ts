import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../service/register.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { Customer } from 'src/app/beans/Customer';

@Component({
  selector: 'app-register-customer',
  templateUrl: './register-customer.component.html',
  styleUrls: ['./register-customer.component.css']
})
export class RegisterCustomerComponent implements OnInit {
  registerService: RegisterService;
  router: Router;
  model: any = {};
  constructor(registerService: RegisterService, private spinner: NgxSpinnerService, router: Router) {
    this.registerService = registerService;
    this.router = router;
  }

  registerCustomer(data: Customer) {
    var customer = this.registerService.registerCustomer(data)
    customer.subscribe((data) => {
      alert("Register Successfully :-)\nYour Account Id is : " + data.customerId)
      this.router.navigate(['login'])
    })
  }

  ngOnInit() {
    this.spinner.show();
    setTimeout(() => {
      this.spinner.hide();
    }, 3000);
  }
}
