import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private spinner: NgxSpinnerService) { }

  ngOnInit() {
        this.spinner.show();
        setTimeout(() => {
          this.spinner.hide();
        }, 3000);
  }

}
