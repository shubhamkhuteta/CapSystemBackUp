import { Component, OnInit } from '@angular/core';
import { Merchant } from 'src/app/beans/Merchant';
import { MerchantServiceService } from '../../services/merchant-service.service';


@Component({
  selector: 'app-merchant-profile',
  templateUrl: './merchant-profile.component.html',
  styleUrls: ['./merchant-profile.component.css']
})
export class MerchantProfileComponent implements OnInit {

  merchant:Merchant;
  constructor(private merchantService:MerchantServiceService) {
    this.merchantService = merchantService;
   }

  ngOnInit() {

    let obj = this.merchantService.getMerchantProfile();
    obj
      .subscribe((data) => {
          console.log("Merchant : "+data);
          this.merchant = new Merchant(data.merchantId,data.merchantName,data.merchantPassword,data.merchantContactNo,data.merchantGSTNo,data.merchantCompanyName,null,0,0,null);

      })

    // "merchantId": 10000,
    // "merchantName": "name",
    // "merchantPassword": "password",
    // "merchantContactNo": "8693098441",
    // "merchantGSTNo": "123456789",
    // "merchantCompanyName": "merchant",
    // "merchantStatus": "ACTIVE",
    // "merchantDiscount": 20,
    // "merchantQuestion": 1,
    // "merchantAnswer": "dog"
    
  }

}
