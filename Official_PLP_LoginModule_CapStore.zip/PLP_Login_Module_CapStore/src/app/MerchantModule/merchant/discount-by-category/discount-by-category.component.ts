import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discount-by-category',
  templateUrl: './discount-by-category.component.html',
  styleUrls: ['./discount-by-category.component.css']
})
export class DiscountByCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
