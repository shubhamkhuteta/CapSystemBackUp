import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MerchantFeedback } from 'src/app/beans/MerchantFeedback';
import { MerchantServiceService } from '../../services/merchant-service.service';

@Component({
  selector: 'app-feedback-response',
  templateUrl: './feedback-response.component.html',
  styleUrls: ['./feedback-response.component.css']
})
export class FeedbackResponseComponent implements OnInit {

  feedbacks: MerchantFeedback[] = [];
  constructor(private merchantService: MerchantServiceService, private router: Router) {
    this.merchantService = merchantService;
    this.router = router;
  }

  ngOnInit() {
    this.fetchFeedback();
  }

  fetchFeedback() {
    var obj = this.merchantService.fetchMerchantFeedback();
    obj.subscribe((data) => {
      console.log(data);
      if (data.length == 0) {
        alert("No Data")
        this.router.navigate(['merchant'])

      }
      else {
        for (let a of data) {
          let obj = new MerchantFeedback(a.id, a.customer, a.merchantFeedback, a.adminComment, a.status);
          this.feedbacks.push(obj);
          // console.log(data)
        }
      }
    })
  }

  feedbackResponse(id: number, response: string) {
    var obj = this.merchantService.sendFeedbackResponse(id, response);
    obj.subscribe(() => {
      this.feedbacks = [];
      this.fetchFeedback();
    })

  }

}

