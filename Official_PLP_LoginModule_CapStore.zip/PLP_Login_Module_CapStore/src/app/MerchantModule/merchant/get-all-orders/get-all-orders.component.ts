import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { MerchantServiceService } from '../../services/merchant-service.service';
import { Order } from 'src/app/beans/Order';

@Component({
  selector: 'app-get-all-orders',
  templateUrl: './get-all-orders.component.html',
  styleUrls: ['./get-all-orders.component.css']
})
export class GetAllOrdersComponent implements OnInit {

  orders:Order[] = []
  constructor(private merchantService:MerchantServiceService,private router:Router) {
    this.merchantService = merchantService;
    this.router = router;
   }

  ngOnInit() {
    let obj = this.merchantService.getAllOrders();
    obj.subscribe((data) => {
      console.log(data);
      if (data.length == 0) {
        alert("No Data")
        this.router.navigate(['merchant']);
      }
      else {
      this.orders = data;
      }
    })

  }

}
