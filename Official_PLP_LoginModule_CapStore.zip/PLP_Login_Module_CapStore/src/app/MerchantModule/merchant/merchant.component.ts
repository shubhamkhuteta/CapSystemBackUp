import { Component, OnInit } from '@angular/core';
import { MerchantServiceService } from '../services/merchant-service.service';
import { Stock } from 'src/app/beans/Stock';

@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css']
})
export class MerchantComponent implements OnInit {


  // values = '';
  //   onKeyUp(event: any) {
  //       this.values = event.target.value;
  //       console.log(this.values);
  //   };
  isStockEmpty: boolean = false;
  isQuantityVisible: boolean = false;
  isDiscountVisible: boolean = false;
  stock: Stock[] = [];
  constructor(private merchantService: MerchantServiceService) {
    this.merchantService = merchantService;
  }

  ngOnInit() {
    this.fetchProducts();
  }

  fetchProducts() {
    let obsvObj = this.merchantService.getAllMerchantsProduct(10);
    obsvObj
      .subscribe((data) => {
        for (let a of data) {
          var stockObj = new Stock(a.product, a.available, a.totalQuantity);
          this.stock.push(stockObj);

          // console.log(this.stock)
        }
      })

  }

  delete(productId: number) {

    // console.log(productId);
    let deleteObj = this.merchantService.deleteProductById(productId);
    deleteObj
      .subscribe((data) => {
        if (data) {
          this.isDiscountVisible = false;
          this.isQuantityVisible = false;
          this.stock = [];
          this.fetchProducts();
        }
      })

  }

  quantityProductId: number = 0;
  editQuantity(productId: number) {
    this.isQuantityVisible = !this.isQuantityVisible;
    if (this.quantityProductId != productId) {
      this.isQuantityVisible = true;
    }
    this.quantityProductId = productId;

  }

  addQuantity(quantity: number) {
    // console.log(quantity);
    let addObj = this.merchantService.addQuantity(this.quantityProductId, quantity);
    addObj
      .subscribe((data) => {
        this.stock = []
        if (this.isSearched == false) {
          this.fetchProducts();
        }
        else {
          let userInput = data.productName;
          this.searchFetch(userInput);
        }

      })
  }

  deleteQuantity(quantity: number) {
    let delObj = this.merchantService.deleteQuantity(this.quantityProductId, quantity);
    delObj
      .subscribe((data) => {
        this.stock = []
        if (this.isSearched == false) {
          this.fetchProducts();
        }
        else {
          let userInput = data.productName;
          this.searchFetch(userInput);
        }
      })
  }

  discountProductId: number = 0;
  editDiscount(productId: number) {
    this.isDiscountVisible = !this.isDiscountVisible;
    if (this.discountProductId != productId) {
      this.isDiscountVisible = true;
    }
    this.discountProductId = productId;

  }

  updateDiscount(discount: number) {
    // console.log(this.discountProductId);
    let disObj = this.merchantService.updateDiscount(this.discountProductId, discount);
    disObj
      .subscribe((data) => {
        this.stock = []
        if (this.isSearched == false) {
          this.fetchProducts();
        }
        else {
          let userInput = data.productName;
          this.searchFetch(userInput);
        }
      })
  }
  isSearched: boolean = false;
  search(event: any) {
    this.isDiscountVisible = false;
    this.isQuantityVisible = false;
    // console.log(userInput)
    if (event.target.value === '') {
      // window.alert("Empty");
      this.stock = []
      this.isStockEmpty = false;
      this.fetchProducts()
    }
    else {
      let userInput = event.target.value;
      this.isSearched = true;
      this.searchFetch(userInput);
    }
  }

  searchFetch(userInput: string) {
    if(userInput.match('[ ]{1,}')){
      console.log("asfs")
      return ;
    }

    let searchObj = this.merchantService.searchMerchantProducts(userInput);
    searchObj
      .subscribe((data) => {
        console.log(data)
        if (data.length === 0) {
          // window.alert("Empty");
          this.isStockEmpty = true;
          this.stock = []
        }
        else {
          this.stock = [];
          for (let a of data) {
            var stockObj = new Stock(a.product, a.available, a.totalQuantity);
            
            this.stock.push(stockObj);
          }
          this.isStockEmpty = false;
        }
      })
  }

}
