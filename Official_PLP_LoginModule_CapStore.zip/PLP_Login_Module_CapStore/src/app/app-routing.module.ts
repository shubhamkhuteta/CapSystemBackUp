import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './LoginModule/login/login.component';
import { RegisterComponent } from './LoginModule/register/register.component';
import { RegisterCustomerComponent } from './LoginModule/register-customer/register-customer.component';
import { RegisterMerchantComponent } from './LoginModule/register-merchant/register-merchant.component';
import { ForgetpasswordComponent } from './LoginModule/forgetpassword/forgetpassword.component';
import { GuardGuard } from './authguard/guard.guard';
import { LogoutComponent } from './LoginModule/logout/logout.component';
import { HomepageComponent } from './LoginModule/homepage/homepage.component';
import { DashboardComponent } from './LoginModule/dashboard/dashboard.component';
import { MerchantComponent } from './MerchantModule/merchant/merchant.component';
import { MerchantProfileComponent } from './MerchantModule/merchant/merchant-profile/merchant-profile.component';
import { AddProductComponent } from './MerchantModule/merchant/add-product/add-product.component';
import { DiscountByCategoryComponent } from './MerchantModule/merchant/discount-by-category/discount-by-category.component';
import { GetAllOrdersComponent } from './MerchantModule/merchant/get-all-orders/get-all-orders.component';
import { FeedbackResponseComponent } from './MerchantModule/merchant/feedback-response/feedback-response.component';


const routes: Routes = [
  // Login Module
  { path: '', redirectTo: 'app-homepage', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'app-register', component: RegisterComponent },
  { path: 'app-register/app-register-customer', component: RegisterCustomerComponent },
  { path: 'app-register/app-register-merchant', component: RegisterMerchantComponent },
  { path: 'login/app-forgetpassword', component: ForgetpasswordComponent },
  { path: 'logout', component: LogoutComponent, canActivate: [GuardGuard] },
  { path: 'app-homepage', component: HomepageComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [GuardGuard] },
  // Merchant Module
  { path: 'merchant', component: MerchantComponent },
  { path: 'merchant/merchantProfile', component: MerchantProfileComponent },
  { path: 'merchant/addProduct', component: AddProductComponent },
  { path: 'merchant/discountByCategory', component: DiscountByCategoryComponent },
  { path: 'merchant/getAllOrders', component: GetAllOrdersComponent },
  { path: 'merchant/feedbackResponse', component: FeedbackResponseComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
