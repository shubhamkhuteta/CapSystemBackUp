import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './LoginModule/login/login.component';
import { LogoutComponent } from './LoginModule/logout/logout.component';
import { RegisterCustomerComponent } from './LoginModule/register-customer/register-customer.component';
import { RegisterMerchantComponent } from './LoginModule/register-merchant/register-merchant.component';
import { RegisterComponent } from './LoginModule/register/register.component';
import { ForgetpasswordComponent } from './LoginModule/forgetpassword/forgetpassword.component';
import { HomepageComponent } from './LoginModule/homepage/homepage.component';
import { DashboardComponent } from './LoginModule/dashboard/dashboard.component';
import { ChangepasswordComponent } from './LoginModule/changepassword/changepassword.component';
// External
import { NgxSpinnerModule } from 'ngx-spinner';
// Merchant Module
import { MerchantComponent } from './MerchantModule/merchant/merchant.component';
import { MerchantProfileComponent } from './MerchantModule/merchant/merchant-profile/merchant-profile.component';
import { AddProductComponent } from './MerchantModule/merchant/add-product/add-product.component';
import { GetAllOrdersComponent } from './MerchantModule/merchant/get-all-orders/get-all-orders.component';
import { DiscountByCategoryComponent } from './MerchantModule/merchant/discount-by-category/discount-by-category.component';
import { FeedbackResponseComponent } from './MerchantModule/merchant/feedback-response/feedback-response.component';
// Services
import { LoginService } from './LoginModule/service/login.service';
import { MerchantServiceService } from './MerchantModule/services/merchant-service.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    LogoutComponent,
    RegisterCustomerComponent,
    RegisterMerchantComponent,
    RegisterComponent,
    ForgetpasswordComponent,
    HomepageComponent,
    DashboardComponent,
    ChangepasswordComponent,
    // Merchant Components
    MerchantComponent,
    MerchantProfileComponent,
    AddProductComponent,
    GetAllOrdersComponent,
    DiscountByCategoryComponent,
    FeedbackResponseComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
  ],
  providers: [MerchantServiceService,LoginService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
