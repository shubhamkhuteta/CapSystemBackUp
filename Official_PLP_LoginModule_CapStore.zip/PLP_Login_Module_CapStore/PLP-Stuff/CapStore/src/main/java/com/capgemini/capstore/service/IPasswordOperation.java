package com.capgemini.capstore.service;

import org.springframework.web.bind.annotation.PathVariable;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.exceptions.CapStoreException;

public interface IPasswordOperation {

	boolean changePasswordCustomer(long customerId, String oldPassword, String newPassword)
			throws CapStoreException;

	public boolean forgetPassword(@PathVariable long customerId, Integer customerQuestion, String customerAnswer,
			String newPassword) throws CapStoreException;

	long findByCustomerContactNo(String customerContactNo);

	boolean changePasswordMerchant(long merchantId, String oldPassword, String newPassword)
			throws CapStoreException;

	boolean forgetPassword(long merchantId, int merchantQuestion, String merchantAnswer, String newPassword
			) throws CapStoreException;

	long findByMerchantContactNo(String merchantContactNo);
}
