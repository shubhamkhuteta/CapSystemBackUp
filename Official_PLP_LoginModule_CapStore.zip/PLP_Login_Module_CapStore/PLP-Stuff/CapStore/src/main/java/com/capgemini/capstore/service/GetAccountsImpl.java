package com.capgemini.capstore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.IAdminDao;
import com.capgemini.capstore.dao.ICustomerDao;
import com.capgemini.capstore.dao.IMerchantDao;
import com.capgemini.capstore.util.Decryption;

@Service
public class GetAccountsImpl implements IGetAccounts{
	
	@Autowired
	IAdminDao adminDao;

	@Autowired
	ICustomerDao customerDao;
	
	@Autowired
	IMerchantDao merchantDao;

	@Override
	public List<Admin> getAdminsAccounts() {
		List<Admin> admins =  adminDao.findAll();
		List<Admin> tempAdmin = new ArrayList<Admin>();
		for(int i =0;i<admins.size();i++) {
			Admin admin = admins.get(i);
			admin.setAdminPassword(Decryption.decrypt(admin.getAdminPassword()));
			tempAdmin.add(admin);
		}
		return tempAdmin;
	}

	@Override
	public List<Customer> getCustomerAccounts() {
		List<Customer> customers =  customerDao.findAll();
		List<Customer> tempCustomer = new ArrayList<Customer>();
		for(int i =0;i<customers.size();i++) {
			Customer customer = customers.get(i);
			customer.setCustomerPassword(Decryption.decrypt(customer.getCustomerPassword()));
			tempCustomer.add(customer);
		}
		return tempCustomer;
	}

	@Override
	
	public List<Merchant> getMerchantAccounts() {
		List<Merchant> merchants =  merchantDao.findAll();
		List<Merchant> tempMerchant = new ArrayList<Merchant>();
		for(int i =0;i<merchants.size();i++) {
			Merchant merchant = merchants.get(i);
			merchant.setMerchantPassword(Decryption.decrypt(merchant.getMerchantPassword()));
			tempMerchant.add(merchant);
		}
		return tempMerchant;
	}
	
}
